if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js').catch(error => {
      console.warn('Не удалось подготовить офлайн-режим.', error);
    });
  }, { once: true });
}
